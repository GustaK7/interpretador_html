package com.example.interpretador_brhtml_desktop

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
